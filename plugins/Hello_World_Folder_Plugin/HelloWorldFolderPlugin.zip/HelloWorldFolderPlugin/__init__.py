# plugins/SampleFolderPlugin/__init__.py

from .hello import run

# 必要ならバージョン情報などもここに書ける
PLUGIN_NAME = "Hello World Folder Plugin"
PLUGIN_VERSION = "2026.01.05"
PLUGIN_AUTHOR = "HiroYokoyama"

