# plugins/HelloWorldPlugin/hello.py
from PyQt6.QtWidgets import QMessageBox

def run(molecule=None):
    print("Hello from Folder Plugin!")
    QMessageBox.information(None, "Hello", "Hello World from Folder!")
    